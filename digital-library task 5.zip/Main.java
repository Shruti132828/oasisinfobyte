/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class Book {
    int id;
    String title;
    String author;
    boolean isIssued;

    Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isIssued = false;
    }
}

class Library {
    ArrayList<Book> books = new ArrayList<>();

    // Add a new book
    void addBook(int id, String title, String author) {
        books.add(new Book(id, title, author));
        System.out.println("Book added successfully!");
    }

    // Remove a book
    void removeBook(int id) {
        for (Book b : books) {
            if (b.id == id) {
                books.remove(b);
                System.out.println("Book removed successfully!");
                return;
            }
        }
        System.out.println("Book not found!");
    }

    // View all books
    void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the library!");
        } else {
            System.out.println("\n--- Book List ---");
            for (Book b : books) {
                System.out.println("ID: " + b.id + " | " + b.title + " by " + b.author +
                        (b.isIssued ? " [Issued]" : " [Available]"));
            }
        }
    }

    // Search a book
    void searchBook(String keyword) {
        boolean found = false;
        for (Book b : books) {
            if (b.title.toLowerCase().contains(keyword.toLowerCase()) ||
                b.author.toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println("Found -> ID: " + b.id + " | " + b.title + " by " + b.author);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No matching book found.");
        }
    }

    // Issue a book
    void issueBook(int id) {
        for (Book b : books) {
            if (b.id == id) {
                if (!b.isIssued) {
                    b.isIssued = true;
                    System.out.println("Book issued successfully!");
                } else {
                    System.out.println("Book already issued!");
                }
                return;
            }
        }
        System.out.println("Book not found!");
    }

    // Return a book
    void returnBook(int id) {
        for (Book b : books) {
            if (b.id == id) {
                if (b.isIssued) {
                    b.isIssued = false;
                    System.out.println("Book returned successfully!");
                } else {
                    System.out.println("Book was not issued!");
                }
                return;
            }
        }
        System.out.println("Book not found!");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Library library = new Library();

        // Preload some sample books
        library.addBook(1, "The Alchemist", "Paulo Coelho");
        library.addBook(2, "1984", "George Orwell");
        library.addBook(3, "To Kill a Mockingbird", "Harper Lee");

        System.out.println("===== DIGITAL LIBRARY MANAGEMENT SYSTEM =====");

        while (true) {
            System.out.println("\nLogin as:");
            System.out.println("1. Admin");
            System.out.println("2. User");
            System.out.println("3. Exit");
            System.out.print("Choose option: ");
            int role = sc.nextInt();

            if (role == 1) { // Admin Section
                System.out.print("Enter Admin Password: ");
                String pass = sc.next();
                if (!pass.equals("admin123")) {
                    System.out.println("Incorrect password!");
                    continue;
                }

                char choice;
                do {
                    System.out.println("\n===== ADMIN MENU =====");
                    System.out.println("A. Add Book");
                    System.out.println("B. Remove Book");
                    System.out.println("C. View All Books");
                    System.out.println("D. Logout");
                    System.out.print("Enter your choice: ");
                    choice = sc.next().toUpperCase().charAt(0);

                    switch (choice) {
                        case 'A':
                            System.out.print("Enter Book ID: ");
                            int id = sc.nextInt();
                            sc.nextLine(); // consume newline
                            System.out.print("Enter Book Title: ");
                            String title = sc.nextLine();
                            System.out.print("Enter Author: ");
                            String author = sc.nextLine();
                            library.addBook(id, title, author);
                            break;

                        case 'B':
                            System.out.print("Enter Book ID to remove: ");
                            int remId = sc.nextInt();
                            library.removeBook(remId);
                            break;

                        case 'C':
                            library.viewBooks();
                            break;

                        case 'D':
                            System.out.println("Logging out of admin...");
                            break;

                        default:
                            System.out.println("Invalid option!");
                    }
                } while (choice != 'D');
            }

            else if (role == 2) { // User Section
                char option;
                do {
                    System.out.println("\n===== USER MENU =====");
                    System.out.println("A. View Books");
                    System.out.println("B. Search Book");
                    System.out.println("C. Issue Book");
                    System.out.println("D. Return Book");
                    System.out.println("E. Contact Library (Email)");
                    System.out.println("F. Logout");
                    System.out.print("Enter option: ");
                    option = sc.next().toUpperCase().charAt(0);

                    switch (option) {
                        case 'A':
                            library.viewBooks();
                            break;

                        case 'B':
                            System.out.print("Enter keyword to search: ");
                            sc.nextLine();
                            String keyword = sc.nextLine();
                            library.searchBook(keyword);
                            break;

                        case 'C':
                            System.out.print("Enter Book ID to issue: ");
                            int issueId = sc.nextInt();
                            library.issueBook(issueId);
                            break;

                        case 'D':
                            System.out.print("Enter Book ID to return: ");
                            int returnId = sc.nextInt();
                            library.returnBook(returnId);
                            break;

                        case 'E':
                            System.out.println("For queries, email us at: library@domain.com");
                            break;

                        case 'F':
                            System.out.println("Logging out...");
                            break;

                        default:
                            System.out.println("Invalid option!");
                    }

                } while (option != 'F');
            }

            else if (role == 3) {
                System.out.println("Thank you for using the Library System!");
                break;
            }

            else {
                System.out.println("Invalid choice! Try again.");
            }
        }

        sc.close();
    }
}
