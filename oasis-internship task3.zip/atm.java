/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

class ATM {
    private double balance;
    private double previousTransaction;
    private String customerName;
    private String customerId;

    // Constructor
    ATM(String cname, String cid) {
        customerName = cname;
        customerId = cid;
    }

    // Deposit money
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            previousTransaction = amount;
            System.out.println("Deposited: $" + amount);
        } else {
            System.out.println("Enter a valid amount!");
        }
    }

    // Withdraw money
    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            previousTransaction = -amount;
            System.out.println("Withdrawn: $" + amount);
        } else if (amount > balance) {
            System.out.println("Insufficient balance!");
        } else {
            System.out.println("Enter a valid amount!");
        }
    }

    // Display previous transaction
    void getPreviousTransaction() {
        if (previousTransaction > 0) {
            System.out.println("Last Transaction: Deposited $" + previousTransaction);
        } else if (previousTransaction < 0) {
            System.out.println("Last Transaction: Withdrawn $" + Math.abs(previousTransaction));
        } else {
            System.out.println("No transaction occurred");
        }
    }

    // Transfer money between two ATM objects
    void transfer(ATM receiver, double amount) {
        if (amount > 0 && amount <= balance) {
            this.balance -= amount;
            receiver.balance += amount;
            System.out.println("Transferred $" + amount + " to " + receiver.customerName);
        } else {
            System.out.println("Transfer failed! Check amount or balance.");
        }
    }

    // Display main menu
    void showMenu() {
        char option;
        Scanner sc = new Scanner(System.in);

        System.out.println("\nWelcome, " + customerName);
        System.out.println("Your ID: " + customerId);

        do {
            System.out.println("\n===== ATM MENU =====");
            System.out.println("A. Transaction History");
            System.out.println("B. Deposit");
            System.out.println("C. Withdraw");
            System.out.println("D. Transfer");
            System.out.println("E. Quit");
            System.out.print("Enter an option: ");

            option = sc.next().toUpperCase().charAt(0);

            switch (option) {
                case 'A':
                    getPreviousTransaction();
                    break;

                case 'B':
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = sc.nextDouble();
                    deposit(depositAmount);
                    break;

                case 'C':
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = sc.nextDouble();
                    withdraw(withdrawAmount);
                    break;

                case 'D':
                    System.out.print("Enter receiver name: ");
                    String name = sc.next();
                    System.out.print("Enter receiver ID: ");
                    String id = sc.next();
                    ATM receiver = new ATM(name, id);
                    System.out.print("Enter amount to transfer: ");
                    double transferAmount = sc.nextDouble();
                    transfer(receiver, transferAmount);
                    break;

                case 'E':
                    System.out.println("Thank you for using our ATM!");
                    break;

                default:
                    System.out.println("Invalid option! Try again.");
                    break;
            }

        } while (option != 'E');

        sc.close();
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter User ID: ");
        String userId = sc.next();

        System.out.print("Enter PIN: ");
        int pin = sc.nextInt();

        // Simple login validation
        if (userId.equals("user123") && pin == 1234) {
            ATM atm = new ATM("John Doe", "user123");
            atm.showMenu();
        } else {
            System.out.println("Invalid ID or PIN!");
        }

        sc.close();
    }
}
